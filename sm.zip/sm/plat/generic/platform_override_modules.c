#include <platform_override.h>


const struct platform_override *platform_override_modules[] = {
};

unsigned long platform_override_modules_size = sizeof(platform_override_modules) / sizeof(const struct platform_override *);
