Copyright (c) 2019 Western Digital Corporation or its affiliates.

Third Party Notices
===================

This project includes or partly uses code from the following open source
software subject to the following open source licenses.

libfdt
------

Copyright (C) 2016 Free Electrons
Copyright (C) 2016 NextThing Co.

The libfdt source code is disjunctively dual licensed (GPL-2.0+ or
BSD-2-Clause). Some of this project code is used in OpenSBI under the terms of
the BSD 2-Clause license. The full text of this license can be found in the
file [COPYING.BSD](COPYING.BSD).
