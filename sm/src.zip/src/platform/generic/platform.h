
// No special data needed for default platform
struct platform_enclave_data{

};
